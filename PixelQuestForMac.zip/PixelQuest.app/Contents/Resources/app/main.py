import pygame
import time
from random import random
import random
from decimal import *
from Math import Math
import threading
from functools import wraps
def delay(delay=0.):
    """
    Decorator delaying the execution of a function for a while.
    """
    def wrap(f):
        @wraps(f)
        def delayed(*args, **kwargs):
            timer = threading.Timer(delay, f, args=args, kwargs=kwargs)
            timer.start()
        return delayed
    return wrap

class Timer():
    toClearTimer = False
    def setTimeout(self, fn, time):
        isInvokationCancelled = False
        @delay(time)
        def some_fn():
                if (self.toClearTimer is False):
                        fn()
                else:
                    print('Invokation is cleared!')
        some_fn()
        return isInvokationCancelled
    def setClearTimer(self):
        self.toClearTimer = True
timer = Timer()
pygame.init()
 
white = (255, 255, 255)
yellow = (255, 255, 102)
black = (0, 0, 0)
red = (213, 50, 80)
green = (0, 255, 0)
fuut = False
blue = (50, 153, 213)
img = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/0-1.gif')
img2 = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/0-2.gif')
img3 = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/0-3.gif')
img4 = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/0-4.gif')
theimg = img
dis_width = 2000
dis_height = 1000
themap = 'start'
e = 'sword'
gold = 0
health = 10
awee = 0
map2 = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/map1.gif')
map2 = pygame.transform.scale(map2, (dis_width, dis_height))
map3 = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/0.png')
quest1map = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/map2.png')
quest1map = pygame.transform.scale(quest1map, (dis_width, dis_height))
door = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/door.gif')
shop = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/shop.gif')
sword2 = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/sword.png')
redstaff = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/redstaff.png')
greenstaff = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/greenstaff.png')
button = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/buttonRedStaff.png')
button2 = pygame.image.load('//Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/buttonGreenStaff.png')
infoP = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/info.png')
br = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/br.png')
#
zombieL = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/zombieL.png')
zombieR = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/zombieR.png')
zombieF = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/zombieF.png')
zombieB = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/zombieB.png')
#
bullet = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/redstaffbullet.gif')
bullet2 = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/greenstaffbullet.png')
bullet3 = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/greenstaffbullet2.png')
bullet4 = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/greenstaffbullet3.png')
bullet5 = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/greenstaffbullet4.png')
sign = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/images/sign.png')
icon = pygame.image.load('/Users/jackm/Desktop/PixelQuest.app/Contents/Resources/app/applet.icns')
buttonD = False
buttonD2 = False
dis = pygame.display.set_mode((dis_width, dis_height), pygame.RESIZABLE)
pygame.display.set_caption('PixelQuest')
icon = pygame.transform.scale(icon, (200, 200))
pygame.display.set_icon(icon)
clock = pygame.time.Clock()
inmessage = False
snake_block = 10
snake_speed = 1500
totalSwordRot = 0
#
class setTimeout:
    def __init__(self):
        self.tims = []
        self.number = 0
    def add(self, callback, delay):
        number = self.number
        self.tims.append([callback, delay, number])
    def check(self):
        ps = []
        i = 0
        while i < len(self.tims):
            self.tims[i][2] += snake_speed
            if self.tims[i][2] == self.tims[i][1]:
                self.tims[i][0]()
                ps.append(i)
            i += 1
        for j in range(len(ps)):
            try:
                self.tims.pop(j)
            except IndexError:
                print 'FUCK'
setT = setTimeout()
#
class Keydown:
    def __init__(self):
        self.down = False
        self.key = ''
keydown = Keydown()
font_style = pygame.font.SysFont("bahnschrift", 25)
score_font = pygame.font.SysFont("comicsansms", 35)
class Sword:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.justHit = False
        self.beenDrawn = False
        self.Used = False
        self.justHit = False
        self.face = "left"
    def draw(self):
         global sword2
         sword2 = pygame.transform.scale(sword2, (100, 100))
         if e == 'sword':
            if keydown.key == 'w' or keydown.key == 'd':
                dis.blit(sword2, (position[0] + 30, position[1]))
            else:
                dis.blit(sword2, (position[0] - 60, position[1]))
         else:
            dis.blit(sword2, (380, 100))
    def hit(self):
        global sword2
        global totalSwordRot
        global gold
        if keydown.key == 'd':
            if not self.justHit:
                self.justHit = True
                sword2 = pygame.transform.rotate(sword2, totalSwordRot + -totalSwordRot)
                sword2 = pygame.transform.rotate(sword2, -90)
                totalSwordRot = totalSwordRot - 90
                def checkIfHitZombie():
                    global gold
                    global sword2
                    for i23 in range(len(zombies)):
                        if zombies[i23].alive == True:
                            rect2 = zombies[i23].getImage().get_rect(topleft=(zombies[i23].x, zombies[i23].y))
                            sword2 = pygame.transform.scale(sword2, (100, 100))
                            rect4 = sword2.get_rect(topleft=(position[0] + 30, position[1]))
                            if ( rect4.left + 30 > rect2.left and rect4.right + 30 < rect2.right and rect4.top > rect2.top and rect4.bottom < rect2.bottom) == True:
                                zombies[i23].hp = zombies[i23].hp - 1
                                if zombies[i23].hp <= 0:
                                    zombies[i23].die()
                                    gold = gold + 1
                                return True
                checkIfHitZombie()
                def test():
                    global sword2
                    global totalSwordRot
                    sword2 = pygame.transform.rotate(sword2, 90)
                    totalSwordRot = totalSwordRot + 90
                    self.justHit = False
                f=threading.Timer(.25,test)
                f.start()
        elif keydown.key == 'a':
            if not self.justHit:
                self.justHit = True
                sword2 = pygame.transform.rotate(sword2, totalSwordRot + -totalSwordRot)
                sword2 = pygame.transform.rotate(sword2, 90)
                def checkIfHitZombie():
                   global gold
                   global sword2
                   for i23 in range(len(zombies)):
                       if zombies[i23].alive == True:
                           rect2 = zombies[i23].getImage().get_rect(topleft=(zombies[i23].x, zombies[i23].y))
                           sword2 = pygame.transform.scale(sword2, (100, 100))
                           rect4 = sword2.get_rect(topleft=(position[0] - 60, position[1]))
                           if ( rect4.left - 40 > rect2.left and rect4.right - 40 < rect2.right and rect4.top > rect2.top and rect4.bottom < rect2.bottom ) == True:
                               zombies[i23].hp = zombies[i23].hp - 1
                               if zombies[i23].hp <= 0:
                                   zombies[i23].die()
                                   gold = gold + 1
                               return True
                checkIfHitZombie()
                def test():
                    global sword2
                    sword2 = pygame.transform.rotate(sword2, -90)
                    self.justHit = False
                f=threading.Timer(.25,test)
                f.start()
        elif keydown.key == 's':
             def checkIfHitZombie():
                global gold
                global sword2
                for i23 in range(len(zombies)):
                    if zombies[i23].alive == True:
                        rect2 = zombies[i23].getImage().get_rect(topleft=(zombies[i23].x, zombies[i23].y))
                        sword2 = pygame.transform.scale(sword2, (100, 100))
                        rect4 = sword2.get_rect(topleft=(position[0] - 60, position[1]))
                        if ( rect4.left > rect2.left and rect4.right < rect2.right and rect4.top + 60 > rect2.top and rect4.bottom + 60 < rect2.bottom ) == True:
                            zombies[i23].hp = zombies[i23].hp - 1
                            if zombies[i23].hp <= 0:
                                zombies[i23].die()
                                gold = gold + 1
                            return True
             checkIfHitZombie()
        elif keydown.key == 'w':
            def checkIfHitZombie():
                global gold
                global sword2
                for i23 in range(len(zombies)):
                    if zombies[i23].alive == True:
                        rect2 = zombies[i23].getImage().get_rect(topleft=(zombies[i23].x, zombies[i23].y))
                        sword2 = pygame.transform.scale(sword2, (100, 100))
                        rect4 = sword2.get_rect(topleft=(position[0] + 30, position[1]))
                        if ( rect4.left > rect2.left and rect4.right < rect2.right and rect4.top - 100 > rect2.top and rect4.bottom - 100 < rect2.bottom) == True:
                            zombies[i23].hp = zombies[i23].hp - 1
                            if zombies[i23].hp <= 0:
                                zombies[i23].die()
                                gold = gold + 1
                            return True
            checkIfHitZombie()
class RedStaff:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.price = 5
        self.Used = False
    def draw(self):
        global redstaff
        redstaff = pygame.transform.scale(redstaff, (100, 100))
        if e != 'redstaff':
            dis.blit(redstaff, (self.x, self.y))
        else:
            if keydown.key == 'w' or keydown.key == 'd':
                dis.blit(redstaff, (position[0] + 30, position[1]))
            else:
                dis.blit(redstaff, (position[0] - 60, position[1]))
    def shoot(self, d):
        pass
class GreenStaff:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.price = 7
        self.Used = False
    def draw(self):
        global greenstaff
        greenstaff = pygame.transform.scale(greenstaff, (100, 100))
        if e != 'greenstaff':
            dis.blit(greenstaff, (self.x, self.y))
        else:
            if keydown.key == 'w' or keydown.key == 'd':
                dis.blit(greenstaff, (position[0] + 30, position[1]))
            else:
                dis.blit(greenstaff, (position[0] - 60, position[1]))
greenstaff2 = GreenStaff(300, 100)
class GreenStaffBullet:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.startPosition = (position[0], position[1])
        self.fromStartpositon = 0
        self.justShot = False
        self.shotDirection = ''
    def shoot(self):
        global bullet2
        global bullet3
        global bullet4
        global bullet5
        if not self.justShot:
            self.startPosition = (position[0], position[1])
            self.ye = position[1]
            self.xe = position[0]
            self.y = position[1]
            self.fromStartpositon = 0
            self.shotDirection = keydown.key
            self.justShot = True
            bullet2 = pygame.transform.scale(bullet2, (100, 100))
            bullet3 = pygame.transform.scale(bullet3, (100, 100))
            bullet4 = pygame.transform.scale(bullet4, (100, 100))
            bullet5 = pygame.transform.scale(bullet5, (100, 100))
            if self.shotDirection == 'd':
                dis.blit(bullet2, self.startPosition)
            elif self.shotDirection == 'a':
                dis.blit(bullet3, self.startPosition)
            elif self.shotDirection == 'w':
                dis.blit(bullet4, self.startPosition)
            elif self.shotDirection == 's':
                dis.blit(bullet5, self.startPosition)
        else:
            if self.shotDirection == 'd':
                    dis.blit(bullet2, (self.x, self.y))
            elif self.shotDirection == 'a':
                    dis.blit(bullet3, (self.x, self.y))
            elif self.shotDirection == 'w':
                    dis.blit(bullet4, (self.x, self.y))
            elif self.shotDirection == 's':
                    dis.blit(bullet5, (self.x, self.y))
            if not self.check(bullet2, shop) and not self.checkoutside() and not self.check2():
                if self.shotDirection == 'd':
                    self.fromStartpositon = self.fromStartpositon + 100
                    self.x = self.x + 100
                    self.y = self.ye
                elif self.shotDirection == 'a':
                    self.fromStartpositon = self.fromStartpositon - 100
                    self.x = self.x - 100
                    self.y = self.ye
                elif self.shotDirection == 'w':
                    self.fromStartpositon = self.fromStartpositon - 100
                    self.y = self.y - 100
                    self.x = self.xe
                elif self.shotDirection == 's':
                    self.fromStartpositon = self.fromStartpositon + 100
                    self.y = self.y + 100
                    self.x = self.xe
            else:
                self.x = position[0]
                self.y = position[1]
                self.fromStartpositon = 0
                self.justShot = False
    def check(self, player, el2):
        if themap == 'start':
            rect2 = el2.get_rect(topleft=(500, 10))
            return not (
                self.x > rect2.right or
                self.x < rect2.left or
                self.y < rect2.top or
                self.y > rect2.bottom 
            )
    def check2(self):
        if themap == 'start':
            rect2 = sign.get_rect(topleft=(1670, 190))
            return not (
                self.x > rect2.right or
                self.x < rect2.left or
                self.y < rect2.top or
                self.y > rect2.bottom
            )
    def checkoutside(self):
        return (
            self.x > dis_width or
            self.x < 0 or
            self.y < 0 or
            self.y > dis_height
        )
                
class Zombie:
    def __init__(self, x, y, i):
        self.x = x
        self.y = y
        self.speed = 10
        self.tim = 1
        self.width = 200
        self.height = 200
        self.oi = False
        self.d = 'F'
        self.hp = 5
        self.alive = True
        self.zombie = i
    def draw(self):
        global zombieL
        global zombieR
        global zombieF
        global zombieB
        self.drawSelf()
    def die(self):
        self.alive = False
    def move(self):
        global health
        d = Math.Floor(Math.Random() * 4)
        if d == 0:
            if not self.checkIfHumanNear():
                health = health - 1
                self.y += self.speed
                self.d = 'F'
                self.draw()
            elif not self.checkoutside() or not self.checkIfHumanNear() or self.checkIfZombieNear():
                self.y -= self.speed
                self.d = 'F'
                self.draw()
            elif self.checkoutside():
                self.y = 0
                self.d = 'F'
                self.draw()
        elif d == 1:
            if not self.checkIfHumanNear():
                health = health - 1
                self.y -= self.speed
                self.d = 'B'
                self.draw()
            elif not self.checkoutside() or self.checkIfZombieNear():
                self.y += self.speed
                self.d = 'B'
                self.draw()
            elif self.checkoutside():
                self.y = dis_height - 210
                self.d = 'B'
                self.draw()
        elif d == 2:
            if not self.checkIfHumanNear():
                health = health - 1
                self.x -= self.speed
                self.d = 'R'
                self.draw()
            elif not self.checkoutside() or self.checkIfZombieNear():
                self.x += self.speed
                self.d = 'R'
                self.draw()
            elif self.checkoutside():
                self.x = dis_width - 210
                self.d = 'R'
                self.draw()
        elif d == 3:
            if not self.checkIfHumanNear():
                health = health - 1
                self.x += self.speed
                self.d = 'L'
                self.draw()
            elif not self.checkoutside() or self.checkIfZombieNear():
                self.x -= self.speed
                self.d = 'L'
                self.draw()
            elif self.checkoutside():
                self.x = 0
                self.d = 'L'
                self.draw()
        self.drawSelf()
    def checkoutside(self):
        return (
            self.x > dis_width or
            self.x < 0 or
            self.y < 0 or
            self.y > dis_height
        )
    def checkIfZombieNear(self):
        for i23 in range(len(zombies)):
            if i23 != self.zombie and zombies[i23].alive == True:
                rect2 = zombies[i23].getImage().get_rect(topleft=(zombies[i23].x, zombies[i23].y))
                # if not check is true, return, else do not
                if not ( self.x > rect2.right or self.x < rect2.left or self.y < rect2.top or self.y > rect2.bottom) == True:
                    return True
    def checkIfHumanNear(self):
        global theimg
        rect2 = theimg.get_rect(topleft=(position[0], position[1]))
        return (
            self.x - 20 > rect2.right or
            self.x < rect2.left or
            self.y - 30 < rect2.top or
            self.y - 20 > rect2.bottom
        )
    def drawSelf(self):
        global zombieL
        global zombieR
        global zombieF
        global zombieB
        if pygame.display.get_active():
            zombieL = self.grow(zombieL)
            zombieR = self.grow(zombieR)
            zombieF = self.grow(zombieF)
            zombieB = self.grow(zombieB)
            if self.d == 'F':
                dis.blit(zombieF, (self.x, self.y))
            elif self.d == 'B':
                dis.blit(zombieB, (self.x, self.y))
            elif self.d == 'R':
                dis.blit(zombieR, (self.x, self.y))
            elif self.d == 'L':
                dis.blit(zombieL, (self.x, self.y))
    def getImage(self):
        global zombieL
        zombieL = self.grow(zombieL)
        return zombieL
    def grow(self, what):
        return pygame.transform.scale(what, (self.width, self.height))
zombies = [Zombie(100, 200, 0), Zombie(500, 500, 1), Zombie(700, 700, 2), Zombie(800, 200, 3), Zombie(900, 300, 4)]
class RedStaffBullet:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.startPosition = (position[0], position[1])
        self.fromStartpositon = 0
        self.justShot = False
        self.shotDirection = ''
    def shoot(self):
        if not self.justShot:
            self.startPosition = (position[0], position[1])
            self.ye = position[1]
            self.xe = position[0]
            self.y = position[1]
            self.fromStartpositon = 0
            self.shotDirection = keydown.key
            self.justShot = True
            dis.blit(bullet, self.startPosition)
        else:
            dis.blit(bullet, (self.x, self.y))
            if not self.check(bullet, shop) and not self.checkoutside() and not self.check2():
                if self.shotDirection == 'd':
                    self.fromStartpositon = self.fromStartpositon + 100
                    self.x = self.x + 100
                    self.y = self.ye
                elif self.shotDirection == 'a':
                    self.fromStartpositon = self.fromStartpositon - 100
                    self.x = self.x - 100
                    self.y = self.ye
                elif self.shotDirection == 'w':
                    self.fromStartpositon = self.fromStartpositon - 100
                    self.y = self.y - 100
                    self.x = self.xe
                elif self.shotDirection == 's':
                    self.fromStartpositon = self.fromStartpositon + 100
                    self.y = self.y + 100
                    self.x = self.xe
            else:
                self.x = position[0]
                self.y = position[1]
                self.fromStartpositon = 0
                self.justShot = False
    def check(self, player, el2):
        if themap == 'start':
            rect2 = el2.get_rect(topleft=(500, 10))
            return not (
                self.x > rect2.right or
                self.x < rect2.left or
                self.y < rect2.top or
                self.y > rect2.bottom 
            )
        elif themap == 'shop':
            return False
    def check2(self):
        if themap == 'start':
            rect2 = sign.get_rect(topleft=(1670, 190))
            return not (
                self.x > rect2.right or
                self.x < rect2.left or
                self.y < rect2.top or
                self.y > rect2.bottom
            )
    def checkoutside(self):
        return (
            self.x > dis_width or
            self.x < 0 or
            self.y < 0 or
            self.y > dis_height
        )
redstaff2 = RedStaff(160, 100)
sword = Sword(10, 10)
def Your_score(score):
    value = score_font.render("Your Score: " + str(score), True, yellow)
    dis.blit(value, [0, 0])
 
 
 
def our_snake(snake_block, snake_list):
    for x in snake_list:
        pygame.draw.rect(dis, black, [x[0], x[1], snake_block, snake_block])
 
 
def message(msg, were, color):
    mesg = font_style.render(msg, True, color)
    dis.blit(mesg, were)
 
position = [dis_width / 2 - 20, dis_height / 2 - 20]
redstaffB = RedStaffBullet(position[0], position[1])
greenstaffB = GreenStaffBullet(position[0], position[1])
def gameLoop():
    game_over = False
    game_close = False
 
    x1 = dis_width / 2
    y1 = dis_height / 2
 
    x1_change = 0
    y1_change = 0
 
    snake_List = []
    Length_of_snake = 1
 
    foodx = round(random.randrange(0, dis_width - snake_block) / 10.0) * 10.0
    foody = round(random.randrange(0, dis_height - snake_block) / 10.0) * 10.0
    
    while not game_over:
        global dis_width
        global dis_height
        global keydown
        global theimg
        global map2
        global shop
        global themap
        global map3
        global door
        global sword
        global sword2
        global e
        global gold
        global buttonD
        global inmessage
        global buttonD2
        global sign
        global quest1map
        global zombies
        global button
        global button2
        global fuut
        global awee
        global health
        # clear frame
        dis.fill((0, 0, 0))
        surface = pygame.display.get_surface()
        dis_width = surface.get_width()
        dis_height = surface.get_height()
        if themap == 'start':
            map2 = pygame.transform.scale(map2, (dis_width, dis_height))
            dis.blit(map2, (0, 0))
            shop = pygame.transform.scale(shop, (200, 410))
            dis.blit(shop, (500, 10))
            dis.blit(sign, (1700, 250))
            if e == 'sword':
                sword.draw()
            elif e == 'redstaff':
                redstaff2.draw()
            elif e == 'greenstaff':
                greenstaff2.draw()
            dis.blit(theimg, (position[0], position[1]))
            def check(player, el2, offset):
                # 1: top, 2: bottom, 3: left, 4: right 
                rect1 = player
                rect2 = el2
                return not (
                rect1[1] > rect2[1] - offset or
                rect1[0] + 100 < rect2[2] + offset or
                rect1[1] + 100 < rect2[0] + offset or
                rect1[0] > rect2[3] - offset
                )
            def check2():
                if themap == 'start':
                    rect2 = sign.get_rect(topleft=(1670, 190))
                    return not (
                        position[0]> rect2.right or
                        position[0] < rect2.left or
                        position[1] < rect2.top or
                        position[1] > rect2.bottom
                    )
            def checkoutside():
                return (
                    position[0] > dis_width - 50 or
                    position[0] < 0 or
                    position[1] < -50 or
                    position[1] > dis_height - 50
                )
            dis.blit(infoP, (dis_width - 170, 60))
            dis.blit(br, (dis_width - 150, 120))
            message('Gold: ' + str(gold), (dis_width - 140, 100), black)
            message('Health: ' + str(health), (dis_width - 150, 140), black)
            if health <= 0:
                game_close = True
            if redstaffB.justShot == True:
                redstaffB.shoot()
            if greenstaffB.justShot == True:
                greenstaffB.shoot()
            if buttonD == True:
                dis.blit(button, (dis_width / 5, dis_height - 200))
                inmessage = True
            elif buttonD2 == True:
                dis.blit(button2, (dis_width / 5, dis_height - 200))
                inmessage = True
        elif themap == 'shop':
            def checkoutside():
                return (
                    position[0] > dis_width - 50 or
                    position[0] < 0 or
                    position[1] < 0 or
                    position[1] > dis_height - 50
                )
            map3 = pygame.transform.scale(map3, (dis_width, dis_height))
            dis.blit(map3, (0, 0))
            door = pygame.transform.scale(door, (300, 500))
            dis.blit(door, ((dis_width / 2) - 300, -100))
            dis.blit(door, ((dis_width / 2), -100))
            redstaff2.draw()
            sword.draw()
            greenstaff2.draw()
            dis.blit(theimg, (position[0], position[1]))
            dis.blit(infoP, (dis_width - 170, 60))
            dis.blit(br, (dis_width - 150, 120))
            message('Gold: ' + str(gold), (dis_width - 140, 100), black)
            message('Health: ' + str(health), (dis_width - 150, 140), black)
            if health <= 0:
                game_close = True
            if redstaffB.justShot == True:
                redstaffB.shoot()
            if greenstaffB.justShot == True:
                greenstaffB.shoot()
            if buttonD == True:
                button = pygame.transform.scale(button, (dis_width / Decimal('1.5'), dis_height / 6))

                dis.blit(button, (dis_width / 5, dis_height - 200))
                inmessage = True
            elif buttonD2 == True:
                button2 = pygame.transform.scale(button2, (dis_width / Decimal('1.5'), dis_height / 6))
                dis.blit(button2, (dis_width / 5, dis_height - 200))
                inmessage = True
        elif themap == 'quest1':
            quest1map = pygame.transform.scale(quest1map, (dis_width, dis_height))
            if pygame.display.get_active():
                dis.blit(quest1map, (0, 0))
            def cec():
                num = 0
                for i34 in range(len(zombies)):
                    num = num + 1
                    if zombies[i34].alive == True:
                        zombies[i34].move()
                fuut = False
                timer.setTimeout(hiu, 1.0)
            def hiu():
                fuut = False
            if fuut == False or awee > 10:
                awee = 0
                cec()
                fuut = True
            elif fuut == True:
                  awee = awee + 1
                  for i345 in range(len(zombies)):
                    if zombies[i345].alive == True:
                        zombies[i345].draw()
            if e == 'sword':
                sword.draw()
            elif e == 'redstaff':
                redstaff2.draw()
            elif e == 'greenstaff':
                greenstaff2.draw()
            dis.blit(theimg, (position[0], position[1]))
            def check(player, el2, offset):
                # 1: top, 2: bottom, 3: left, 4: right 
                rect1 = player
                rect2 = el2
                return not (
                rect1[1] > rect2[1] - offset or
                rect1[0] + 100 < rect2[2] + offset or
                rect1[1] + 100 < rect2[0] + offset or
                rect1[0] > rect2[3] - offset
                )
            def checkoutside():
                return (
                    position[0] > dis_width - 50 or
                    position[0] < 0 or
                    position[1] < -50 or
                    position[1] > dis_height - 50
                )
            dis.blit(infoP, (dis_width - 170, 60))
            dis.blit(br, (dis_width - 150, 120))
            message('Gold: ' + str(gold), (dis_width - 140, 100), black)
            message('Health: ' + str(health), (dis_width - 150, 140), black)
            if health <= 0:
                game_close = True
            if redstaffB.justShot == True:
                redstaffB.shoot()
            if greenstaffB.justShot == True:
                greenstaffB.shoot()
            if buttonD == True:
                dis.blit(button, (dis_width / 5, dis_height - 200))
                inmessage = True
            elif buttonD2 == True:
                dis.blit(button2, (dis_width / 5, dis_height - 200))
                inmessage = True
        while game_close == True:
            dis.fill(blue)
            message("Your Dead! Press Q to Quit", (dis_width / 2, dis_height / 2), red)
            pygame.display.update()
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        game_over = True
                        game_close = False
 
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            if event.type == pygame.KEYDOWN and inmessage == False:
                if event.key == pygame.K_w:
                    position[1] = position[1] - 10
                    if themap == 'start':
                        if check(position, [10, 350, 500, 700], 0) == True:
                            position[1] = position[1] + 10
                            themap = 'shop'
                        if check2() == True:
                           position[1] = position[1] + 10
                        elif checkoutside() == True:
                            position[1] = position[1] + 10
                    elif themap == 'shop':
                        if checkoutside() == True:
                            position[1] = position[1] + 10
                            themap = 'start'
                            position[0] = 600
                            position[1] = 600
                    elif themap == 'quest1':
                        if checkoutside() == True:
                            position[1] = position[1] + 10
                        if checkIfZombieHitYou() == True:
                            health = health - 1
                            position[1] = position[1] + 10
                    theimg = img
                    keydown.down = True
                    keydown.key = 'w'
                elif event.key == pygame.K_s:
                    position[1] = position[1] + 10
                    if themap == 'start':
                        if check(position, [10, 350, 500, 700], 0) == True:
                            position[1] = position[1] - 10
                        if check2() == True:
                            position[1] = position[1] - 10
                    elif themap == 'quest1':
                        if checkIfZombieHitYou() == True:
                            health = health - 1
                            position[1] = position[1] - 10
                    if checkoutside() == True:
                        position[1] = position[1] - 10
                    theimg = img3
                    keydown.down = True
                    keydown.key = 's'
                elif event.key == pygame.K_a:
                    position[0] = position[0] - 10
                    if themap == 'start':
                        if check(position, [10, 350, 500, 700], 0) == True:
                            position[0] = position[0] + 10
                        if check2() == True:
                            position[0] = position[0] + 10
                    elif themap == 'quest1':
                        if checkoutside() == True:
                            position[0] = dis_width - 50
                            themap = 'start'
                        if checkIfZombieHitYou() == True:
                            health = health - 1
                            position[0] = position[0] + 10
                    if checkoutside() == True:
                        position[0] = position[0] + 10
                    theimg = img4
                    keydown.down = True
                    keydown.key = 'a'
                elif event.key == pygame.K_d:
                    position[0] = position[0] + 10
                    if themap == 'start':
                        if check(position, [10, 350, 500, 700], 0) == True:
                            position[0] = position[0] - 10
                        if check2() == True:
                            position[0] = position[0] - 10
                        if checkoutside() == True:
                            position[0] = 50
                            themap = 'quest1'
                    elif themap == 'quest1':
                        if checkIfZombieHitYou() == True:
                            health = health - 1
                            position[0] = position[0] - 10
                    if checkoutside() == True:
                        position[0] = position[0] - 10
                    theimg = img2
                    keydown.down = True
                    keydown.key = 'd'
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if buttonD == True:
                    posX, posY = pygame.mouse.get_pos()
                    rect = button.get_rect(topleft=(dis_width / 5, dis_height - 200))
                    def collide():
                        return not (
                            posY > rect.bottom or
                            posX < rect.left or
                            posY < rect.top or
                            posX > rect.right
                        )
                    if collide() == True:
                        buttonD = False
                        inmessage = False
                elif buttonD2 == True:
                    posX, posY = pygame.mouse.get_pos()
                    rect = button2.get_rect(topleft=(dis_width / 5, dis_height - 200))
                    def collide():
                        return not (
                            posY > rect.bottom or
                            posX < rect.left or
                            posY < rect.top or
                            posX > rect.right
                        )
                    if collide() == True:
                        buttonD2 = False
                        inmessage = False
                if e == 'redstaff' and inmessage == False:
                    redstaffB.shoot()
                if e == 'greenstaff' and inmessage == False:
                    greenstaffB.shoot()
                if themap == 'shop' and e != 'redstaff' and inmessage == False:
                    posX, posY = pygame.mouse.get_pos()
                    rect = redstaff.get_rect(topleft=(160, 100))
                    def collide():
                        return not (
                            posY > rect.bottom or
                            posX < rect.left or
                            posY < rect.top or
                            posX > rect.right
                        )
                    if collide() == True:
                        # buy the redstaff
                        if redstaff2.Used == False:
                            if gold > redstaff2.price or gold == redstaff2.price:
                                gold = gold - redstaff2.price
                                e = 'redstaff'
                                redstaff2.Used = True
                            else:
                                buttonD = True
                        else:
                            e = 'redstaff'
                            redstaff2.Used = True
                if themap == 'shop' and e != 'greenstaff' and inmessage == False:
                    posX, posY = pygame.mouse.get_pos()
                    rect = greenstaff.get_rect(topleft=(300, 100))
                    def collide():
                        return not (
                            posY > rect.bottom or
                            posX < rect.left or
                            posY < rect.top or
                            posX > rect.right
                        )
                    if collide() == True:
                        # buy the greenstaff
                        if greenstaff2.Used == False:
                            if gold > greenstaff2.price or gold == greenstaff2.price:
                                gold = gold - greenstaff2.price
                                e = 'greenstaff'
                                greenstaff2.Used = True
                            else:
                                buttonD2 = True
                        else:
                            e = 'greenstaff'
                            greenstaff2.Used = True
                if themap == 'shop' and inmessage == False and e != 'sword':
                    posX, posY = pygame.mouse.get_pos()
                    rect = sword2.get_rect(topleft=(380, 100))
                    def collide():
                        return not (
                            posY > rect.bottom or
                            posX < rect.left or
                            posY < rect.top or
                            posX > rect.right
                        )
                    if collide() == True:
                        e = 'sword'
                if e == 'sword' and inmessage == False:
                    sword.hit()
                elif e == 'redstaff' and inmessage == False:
                    if keydown.key == 'd':
                        redstaff2.shoot('d')
                    elif keydown.key == 'a':
                        redstaff2.shoot('a')
                    elif keydown.key == 's':
                        redstaff2.shoot('a')
                    elif keydown.key == 'w':
                        redstaff2.shoot('w')
                    else:
                        redstaff2.shoot('w')
            elif event.type == pygame.KEYUP:
                if event.key == pygame.K_w:
                    keydown.down = False
                elif event.key == pygame.K_s:
                    keydown.down = False
                elif event.key == pygame.K_a:
                    keydown.down = False
                elif event.key == pygame.K_s:
                    keydown.down = False
                elif event.key == pygame.K_d:
                    keydown.down = False
        if inmessage == False:
            def checkIfZombieHitYou():
                global health
                for i23 in range(len(zombies)):
                    if zombies[i23].alive == True:
                        rect2 = zombies[i23].getImage().get_rect(topleft=(zombies[i23].x, zombies[i23].y))
                        # if not check is true, return, else do not
                        if not ( position[0]> rect2.right - 20 or position[0] < rect2.left or position[1] < rect2.top - 30 or position[1] > rect2.bottom - 20) == True:
                            return True
            if keydown.down == True and keydown.key == 'w':
                position[1] = position[1] - 10
                if themap == 'start':
                    if check(position, [10, 350, 500, 700], 0) == True:
                        position[1] = position[1] + 10
                        themap = 'shop'
                    if check2() == True:
                       position[1] = position[1] + 10 
                    elif checkoutside() == True:
                        position[1] = position[1] + 10
                elif themap == 'shop':
                    if checkoutside() == True:
                        position[1] = position[1] + 10
                        themap = 'start'
                        position[0] = 600
                        position[1] = 600
                elif themap == 'quest1':
                    if checkoutside() == True:
                        position[1] = position[1] + 10
                    if checkIfZombieHitYou() == True:
                        position[1] = position[1] + 10
            elif keydown.down == True and keydown.key == 's':
                position[1] = position[1] + 10
                if themap == 'start':
                    if check(position, [10, 350, 500, 700], 0) == True:
                        position[1] = position[1] - 10
                    if check2() == True:
                        position[1] = position[1] - 10
                elif themap == 'quest1':
                    if checkIfZombieHitYou() == True:
                        position[1] = position[1] - 10
                if checkoutside() == True:
                    position[1] = position[1] - 10 
            elif keydown.down == True and keydown.key == 'a':
                position[0] = position[0] - 10
                if themap == 'start':
                    if check(position, [10, 350, 500, 700], 0) == True:
                        position[0] = position[0] + 10
                    if check2() == True:
                        position[0] = position[0] + 10
                elif themap == 'quest1':
                    if checkoutside() == True:
                        position[0] = dis_width - 50
                        themap = 'start'
                    if checkIfZombieHitYou() == True:
                        position[0] = position[0] + 10
                if checkoutside() == True:
                    position[0] = position[0] + 10
            elif keydown.down == True and keydown.key == 'd':
                position[0] = position[0] + 10
                if themap == 'start':
                    if check(position, [10, 350, 500, 700], 0) == True:
                        position[0] = position[0] - 10
                    if check2() == True:
                        position[0] = position[0] - 10
                    if checkoutside() == True:
                        position[0] = 50
                        themap = 'quest1'
                elif themap == 'quest1':
                    if checkIfZombieHitYou() == True:
                        position[0] = position[0] - 10
                if checkoutside() == True:
                    position[0] = position[0] - 10
        pygame.display.flip()
        clock.tick(snake_speed)
 
    pygame.quit()
    quit()
gameLoop()
# Make Humans be able to kill Zombies!