from random import random
class math:
    def __init__(self):
        self.awsome = True
    def Random(self):
        return random()
    def Floor(self, what):
        what = str(what)
        i = 0
        while i < len(what):
            if what[i] == '.':
                what = what[0:i]
            i += 1
        return int(what)
Math = math()

